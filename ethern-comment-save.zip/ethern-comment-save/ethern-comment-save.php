<?php
/**
 * Plugin Name: Ethern Comment Save
 * Description: Save Comments to database
 * Author: Ethern Myth
 * Version: 1.0.0
 * Text Domain: ethern-comment-save
 */

if(!defined('ABSPATH')){
    exit;
}

class CommentForm {
    public function __construct()
    {
        // Create custom post type
        add_action('init', array($this, 'create_custom_post_type'));

        // Add assets (css, js, images and more)
        add_action('wp_enqueue_scripts', array($this, 'load_assets'));

        // Add Shortcode
        add_shortcode('comment-form', array($this, 'load_shortcode'));

        // Add javascript files at footer
        add_action('wp_footer', array($this, 'load_scripts'));
    }

    public function create_custom_post_type()
    {
        $args = array(
            'public' => true,
            'has_archive' => true,
            'supports' => array('title'),
            'exclude_from_search' => false,
            'publicly_queryable' => false,
            'capability'=> 'manage_options',
            'labels' => array(
                'name' => 'Comment Section',
                'singular_name' => 'Comment Form Entry'
            ),
            'menu_icon' => 'dashboard-media-text',
        );

        register_post_type('ethern-comment-save', $args);
    }

    public function load_assets(){
        wp_enqueue_style(
            'ethern-comment-save', 
            plugin_dir_url(__FILE__). 'css/styles.css', 
            array(),
            1,
            'all'
        );

         wp_enqueue_style(
            'bootstrap', 
            plugin_dir_url(__FILE__). 'css/bootstrap.min.css', 
            array(),
            1,
            'all'
        );

        wp_enqueue_script(
            'ethern-comment-save',
            plugin_dir_url(__FILE__) . 'js/index.js',
            array('jQuery'),
            1,
            true
        );
         wp_enqueue_script(
            'bootstrap',
            plugin_dir_url(__FILE__) . 'js/bootstrap.min.js'
        );
    }

    public function load_shortcode() {?>
    <div class="align-item-center justify-content-center">
        <h1>Add comment</h1>
        <p>Share your thoughts</p>
        <form id="comment__form" class="comment-form">
            <div class="form-group mb-2"> 
                <input 
                type="text" 
                name="name" 
                id="name" 
                placeholder="Your Name" 
                class="form-control" required>
            </div>
            <div class="form-group mb-2"> 
                <textarea 
                placeholder="Type your comment" 
                name="comment" id="comment" 
                cols="50" rows="10" 
                class="form-control" required></textarea>
            </div>
             <div class="form-group"> 
                <button type="submit" class="btn btn-success w-100" >Save</button>
            </div>
        </form>
    </div>
    <?php }

    public function load_scripts() {?>
        <script>
            const formEl = document.querySelector('.comment-form');
            formEl.addEventListener('submit', event=>{
                event.preventDefault();
                const formData = new FormData(formEl);
                const data = new URLSearchParams(formData);
                fetch('https://post-comment-restapi.onrender.com/api/comments',
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: data
                    }
                ).then(res=> res.json())
                .then(data=> {
                    formEl.reset();
                    window.location.href= "https://comments-app-testing.pages.dev/";
                })
                .catch(error=> console.error(error));
            });
        </script>
    <?php }
}

new CommentForm;
?>